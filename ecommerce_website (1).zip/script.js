
// إضافة وظائف بسيطة مثل إضافة المنتج إلى السلة
document.querySelectorAll('.product button').forEach(button => {
  button.addEventListener('click', () => {
    alert('تم إضافة المنتج إلى السلة!');
  });
});
